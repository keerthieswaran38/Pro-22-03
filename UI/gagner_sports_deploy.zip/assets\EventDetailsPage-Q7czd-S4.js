import{bv as h,b1 as p,r as x,j as e,L as j}from"./theme-rfRfjXTD.js";const t=()=>e.jsxs("svg",{className:"ed-detail-icon",width:"20",height:"20",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",children:[e.jsx("path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14"}),e.jsx("polyline",{points:"22 4 12 14.01 9 11.01"})]});function v({events:r,coupons:g}){var d;const{slug:l}=h(),c=p(),n=Object.keys(r).length===0,s=r[l||""]||Object.values(r)[0];return x.useEffect(()=>{window.scrollTo(0,0),gsap.fromTo(".ed-title-wrapper",{y:100,opacity:0},{y:0,opacity:1,duration:1,ease:"power4.out",delay:.5}),gsap.fromTo(".ed-timer-wrapper",{y:50,opacity:0},{y:0,opacity:1,duration:1,ease:"power3.out",delay:.8}),gsap.fromTo(".ed-main",{y:50,opacity:0},{y:0,opacity:1,duration:1,ease:"power3.out",delay:1})},[l]),s?e.jsxs("div",{className:"event-detail-page-mad",children:[e.jsxs("header",{className:"ed-hero",id:"ed-hero",children:[e.jsx("div",{className:"ed-hero-bg",children:e.jsx("img",{src:s.bgImg||s.imageUrl||`/images/${(d=s.slug)==null?void 0:d.replace(/-/g,"_")}.png`,alt:s.title,id:"ed-bg-img"})}),e.jsx("div",{className:"ed-hero-overlay"}),e.jsxs("div",{className:"ed-hero-content",children:[e.jsxs("div",{className:"ed-title-wrapper",children:[e.jsx("div",{className:"ed-badge",id:"ed-hero-tag",children:s.tag||"PREMIUM EVENT"}),e.jsx("h1",{className:"ed-title",id:"ed-hero-title",children:s.title})]}),e.jsxs("div",{className:"ed-timer-wrapper",children:[e.jsx("div",{className:"ed-timer-header",children:"REGISTRATION CLOSES IN"}),e.jsxs("div",{className:"ed-timer-blocks",id:"countdown-timer",children:[e.jsxs("div",{className:"ed-time-block",children:[e.jsx("div",{className:"ed-time-value",children:"25"}),e.jsx("div",{className:"ed-time-label",children:"DAYS"})]}),e.jsx("div",{className:"ed-colon",children:":"}),e.jsxs("div",{className:"ed-time-block",children:[e.jsx("div",{className:"ed-time-value",children:"13"}),e.jsx("div",{className:"ed-time-label",children:"HOURS"})]}),e.jsx("div",{className:"ed-colon",children:":"}),e.jsxs("div",{className:"ed-time-block",children:[e.jsx("div",{className:"ed-time-value",children:"59"}),e.jsx("div",{className:"ed-time-label",children:"MINS"})]}),e.jsx("div",{className:"ed-colon",children:":"}),e.jsxs("div",{className:"ed-time-block",children:[e.jsx("div",{className:"ed-time-value",children:"42"}),e.jsx("div",{className:"ed-time-label",children:"SECS"})]})]})]})]})]}),e.jsxs("main",{className:"ed-main",children:[e.jsxs("div",{className:"ed-left-content",children:[e.jsxs("div",{className:"ed-meta-grid",children:[e.jsxs("div",{className:"ed-meta-card hover-target",children:[e.jsx("div",{className:"ed-meta-label",children:"DATE"}),e.jsx("div",{className:"ed-meta-value",children:s.date})]}),e.jsxs("div",{className:"ed-meta-card hover-target",children:[e.jsx("div",{className:"ed-meta-label",children:"TIME"}),e.jsx("div",{className:"ed-meta-value",children:s.time||"5:30 AM Onwards"})]}),e.jsxs("div",{className:"ed-meta-card hover-target",style:{gridColumn:"span 2"},children:[e.jsx("div",{className:"ed-meta-label",children:"VENUE"}),e.jsx("div",{className:"ed-meta-value",children:s.venue||"Chennai, India"})]})]}),e.jsxs("div",{className:"ed-section",style:{background:"linear-gradient(145deg, rgba(20,20,20,0.6) 0%, rgba(5,5,5,0.9) 100%)",padding:"3rem",borderRadius:"24px",border:"1px solid rgba(255,255,255,0.03)",boxShadow:"0 20px 40px rgba(0,0,0,0.4)"},children:[e.jsxs("h2",{className:"ed-section-title",style:{marginBottom:"2rem"},children:["ABOUT THE ",e.jsx("span",{className:"green",style:{marginLeft:"8px"},children:"EVENT"})]}),e.jsx("div",{className:"ed-desc-text premium-rich-text",dangerouslySetInnerHTML:{__html:s.description||s.desc||"<p>Join us for this amazing premium event!</p>"}})]}),e.jsx("style",{children:`
                  .premium-rich-text {
                      color: rgba(255,255,255,0.85);
                      font-size: 1.15rem;
                      line-height: 2;
                      text-align: left;
                  }
                  .premium-rich-text p {
                      margin-bottom: 1.5rem;
                  }
                  .premium-rich-text h1, 
                  .premium-rich-text h2, 
                  .premium-rich-text h3 {
                      color: #fff;
                      font-weight: 800;
                      margin-top: 2rem;
                      margin-bottom: 1rem;
                      letter-spacing: -0.5px;
                  }
                  .premium-rich-text h2 {
                      font-size: 1.8rem;
                      border-bottom: 1px solid rgba(255,255,255,0.1);
                      padding-bottom: 0.5rem;
                  }
                  .premium-rich-text h3 {
                      font-size: 1.4rem;
                      color: var(--primary);
                  }
                  .premium-rich-text ul, 
                  .premium-rich-text ol {
                      margin: 1.5rem 0;
                      padding-left: 1.5rem;
                      background: rgba(255,255,255,0.02);
                      border-radius: 12px;
                      padding: 1.5rem 1.5rem 1.5rem 3rem;
                      border: 1px solid rgba(255,255,255,0.05);
                  }
                  .premium-rich-text li {
                      margin-bottom: 0.8rem;
                  }
                  .premium-rich-text a {
                      color: var(--secondary);
                      text-decoration: none;
                      border-bottom: 1px dashed var(--secondary);
                      transition: all 0.3s;
                  }
                  .premium-rich-text a:hover {
                      color: #fff;
                      border-bottom-color: #fff;
                  }
                  .premium-rich-text strong {
                      color: #fff;
                      font-weight: 800;
                  }
              `}),e.jsxs("div",{className:"ed-section",children:[e.jsxs("h2",{className:"ed-section-title",children:["CATEGORIES & ",e.jsx("span",{className:"green",style:{marginLeft:"8px"},children:"PRIZES"})]}),e.jsx("div",{className:"ed-categories",children:((s==null?void 0:s.categories)||[]).map((i,a)=>e.jsxs("div",{className:"ed-category-card",children:[e.jsxs("div",{className:"ed-cat-header",children:[e.jsx("div",{className:"ed-cat-title",children:i.name}),e.jsx("div",{className:"ed-cat-price",children:i.price})]}),e.jsx("div",{className:"ed-cat-details",children:(i.details||[]).map((m,o)=>e.jsxs("div",{className:"ed-detail-row",children:[e.jsx(t,{})," ",m]},o))}),i.prizes&&e.jsxs("div",{className:"ed-prize-pool",children:[e.jsx("div",{style:{color:"var(--secondary)",fontSize:"0.8rem",letterSpacing:"2px",fontWeight:800,marginBottom:"1rem"},children:"CASH PRIZES"}),i.prizes["1st"]&&e.jsxs("div",{className:"ed-prize-row",children:[e.jsx("span",{style:{color:"#FFD700"},children:"🥇 1st Place"})," ",e.jsx("span",{children:i.prizes["1st"]})]}),i.prizes["2nd"]&&e.jsxs("div",{className:"ed-prize-row",children:[e.jsx("span",{style:{color:"#C0C0C0"},children:"🥈 2nd Place"})," ",e.jsx("span",{children:i.prizes["2nd"]})]}),i.prizes["3rd"]&&e.jsxs("div",{className:"ed-prize-row",children:[e.jsx("span",{style:{color:"#CD7F32"},children:"🥉 3rd Place"})," ",e.jsx("span",{children:i.prizes["3rd"]})]})]})]},a))})]}),e.jsxs("div",{className:"ed-section",children:[e.jsxs("h2",{className:"ed-section-title",children:["PARTICIPANT ",e.jsx("span",{className:"primary",style:{marginLeft:"8px"},children:"DELIVERABLES"})]}),e.jsx("div",{className:"ed-deliverables-grid",children:(s.deliverables||["Event T-Shirt","Finisher Medal","E-Certificate","Breakfast"]).map((i,a)=>e.jsxs("div",{className:"ed-deliverable-item",children:[e.jsx(t,{})," ",e.jsx("span",{children:i})]},a))})]})]}),e.jsx("div",{className:"ed-right-content",children:e.jsxs("div",{className:"ed-form-panel",children:[e.jsxs("div",{className:"ed-form-header",children:[e.jsxs("h2",{className:"ed-form-title",children:["SECURE YOUR ",e.jsx("span",{className:"primary",children:"SPOT"})]}),e.jsx("p",{className:"ed-form-subtitle",children:"Join thousands of elite participants. Select your category and confirm your registration below."})]}),e.jsxs("form",{onSubmit:i=>{i.preventDefault(),c(`/register/${s.slug}`)},children:[e.jsxs("div",{className:"ed-input-wrapper",children:[e.jsx("input",{type:"text",className:"ed-input",placeholder:" ",required:!0}),e.jsx("label",{className:"ed-label",children:"FULL NAME"})]}),e.jsxs("div",{className:"ed-input-wrapper",children:[e.jsx("input",{type:"email",className:"ed-input",placeholder:" ",required:!0}),e.jsx("label",{className:"ed-label",children:"EMAIL ADDRESS"})]}),e.jsxs("div",{className:"ed-input-wrapper",children:[e.jsx("input",{type:"tel",className:"ed-input",placeholder:" ",required:!0}),e.jsx("label",{className:"ed-label",children:"PHONE NUMBER"})]}),e.jsxs("div",{className:"ed-input-wrapper",children:[e.jsxs("select",{className:"ed-input",required:!0,defaultValue:"",children:[e.jsx("option",{value:"",disabled:!0}),((s==null?void 0:s.categories)||[]).map((i,a)=>e.jsxs("option",{value:i.name,children:[i.name," - ",i.price]},a))]}),e.jsx("label",{className:"ed-label",children:"SELECT CATEGORY"})]}),e.jsxs("button",{type:"submit",className:"btn-gagner-plasma hover-target",children:[e.jsx("span",{className:"plasma-text",children:"BOOK NOW"}),e.jsx("div",{className:"plasma-border"})]})]})]})})]})]}):n?e.jsxs("div",{style:{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"#0a0a0a",color:"#fff"},children:[e.jsx("div",{className:"loading-spinner",style:{width:"40px",height:"40px",border:"3px solid rgba(255,100,0,0.3)",borderTopColor:"#ff6400",borderRadius:"50%",animation:"spin 1s linear infinite"}}),e.jsx("p",{style:{marginTop:"1.5rem",letterSpacing:"2px",fontSize:"0.8rem",opacity:.5},children:"LOADING..."}),e.jsx("style",{children:"@keyframes spin { to { transform: rotate(360deg); } }"})]}):e.jsxs("div",{style:{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"#0a0a0a",padding:"2rem",textAlign:"center"},children:[e.jsx("h2",{style:{fontSize:"2rem",fontWeight:900,marginBottom:"2rem",color:"#fff"},children:"EVENT NOT FOUND"}),e.jsx(j,{to:"/",style:{color:"#ff6400",fontWeight:800,textDecoration:"none",border:"1px solid #ff6400",padding:"1rem 2rem",borderRadius:"4px"},children:"GO BACK HOME"})]})}export{v as default};
